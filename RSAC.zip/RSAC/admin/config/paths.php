<?php

//always provide trailing slash
//This is the url to the projects root
define('URL', 'http://localhost/RSAC/admin/'); // http://166.62.116.233/~project/ or http://localhost/project/

//this is the  relative path to the libs folder
define('LIBS', 'libs/');

//This is the full path to the root folder on the machine
define('FULL_PATH', dirname(__DIR__) . DIRECTORY_SEPARATOR);

define('REQUEST_API',"http://localhost/RSAC/api/request.php");

?>